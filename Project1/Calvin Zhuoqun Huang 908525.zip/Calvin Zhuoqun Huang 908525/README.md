### This is the submission of Calvin Zhuoqun Huang. All work are done by and only by me.

- The data files are included so that if you want to rerun the notebook. It can be run successfully
    - Since I supports the *preprocessing* with ways of specifying path to search for. I haven't tested other path, but it should work without problem.

- I have used some external libraries including Pandas, numpy and matplotlib.
    - (Refer to this thread)[https://app.lms.unimelb.edu.au/webapps/discussionboard/do/message?action=list_messages&course_id=_382053_1&conf_id=_812408_1&forum_id=_461771_1&message_id=_1858857_1&nav=discussion_board_entry]
    - The use of these libraries strictly follows the rules in this thread.
    - There are no usage of any aggregation function. The DataFrame and np.array are simply used as an easier way of indexing

- I've used a rather complex structure for my Bayes Learner.
    - The few most important **methods** and **properties/attributes** have been listed in the doc. So please search these keywords.

- I think the questions are impossible to answer without supporting my answers with evidences.
    - The answers I composed is not what strictly follows some analysis on lecture, but what to me makes more sense.


2019 Wed 03 Apr  
